package com.mycompany.jardinmain;


public class Arbusto extends Planta implements Podar{
    private static final int MIN_FOLLAJE = 1;
    private static final int MAX_FOLLAJE = 10;
    private int densidad;

    public Arbusto(int densidad, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        if(densidad < MIN_FOLLAJE || densidad > MAX_FOLLAJE){
            throw new IllegalArgumentException("Valor de follaje invalido");
        }
        this.densidad = densidad;
    }

    @Override
    public void podar() {
        System.out.println("El Arbusto " + getNombre() + " se esta podando");
    }
    
    @Override
    public String toString() {
        return "Arbusto( " + "densidad del follaje= " + densidad + super.toString();
    }
}
