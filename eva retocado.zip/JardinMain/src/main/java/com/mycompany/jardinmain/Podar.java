package com.mycompany.jardinmain;

public interface Podar {
    
    void podar();
}
