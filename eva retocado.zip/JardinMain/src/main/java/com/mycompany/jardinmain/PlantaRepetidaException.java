
package com.mycompany.jardinmain;


public class PlantaRepetidaException extends RuntimeException{
    
    private static final String MSG = "Planta repetida";
    
    public PlantaRepetidaException(){
        super(MSG);
    }
}
