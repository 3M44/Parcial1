package com.mycompany.jardinmain;

import java.util.ArrayList;

public class JardinBotanico {
    
    private ArrayList<Planta> plantas = new ArrayList<>();
    
    public void agregarPlanta(Planta planta){
        for (Planta p : plantas){
            if (p.equals(planta)){
                throw new PlantaRepetidaException();
            }
        }
        plantas.add(planta);
    }
    
    
    
    public void mostrarPlantas(){
        for (Planta p : plantas){
            System.out.println(p);
        }
    }
    
    public void podarPlantas(){
        for (Planta p : plantas){
            if(p instanceof Podar podable){
                podable.podar();
            }
            else{
                System.out.println(p.getNombre() + " no se puede podar");
            }
        }
    }
}
