package com.mycompany.jardinmain;


public class Arbol extends Planta implements Podar{
    private int altura;

    public Arbol(int altura, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.altura = altura;
    }

    @Override
    public void podar() {
        System.out.println("El Arbol " + getNombre() + " se esta podando");
    }
    
    @Override
    public String toString() {
        return "Arbol( " + "Altura Maxima= " + altura + super.toString();
    }
    
    }

    
    
    
